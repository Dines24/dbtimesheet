-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 27, 2020 at 12:18 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `timesheet-backend`
--

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `is_active` enum('1','0','','') NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`, `is_active`, `created_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'web development', '1', 1, '2020-02-26 00:39:40', '2020-02-26 00:39:40', NULL),
(2, 'mobile development', '1', 1, '2020-02-26 00:40:15', '2020-02-26 00:40:15', NULL),
(3, 'sd', '1', 1, '2020-02-26 23:43:08', '2020-02-26 23:43:16', '2020-02-27 05:13:16'),
(4, 'Quality Analyst', '1', 1, '2020-02-27 00:22:40', '2020-02-27 00:22:40', NULL),
(5, 'Business development', '1', 1, '2020-02-27 00:35:28', '2020-02-27 00:35:28', NULL),
(6, 'BDE', '1', 1, '2020-02-27 05:39:35', '2020-02-27 05:41:23', '2020-02-27 11:11:23');

-- --------------------------------------------------------

--
-- Table structure for table `designation`
--

CREATE TABLE `designation` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `is_active` enum('1','0','','') NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `designation`
--

INSERT INTO `designation` (`id`, `name`, `is_active`, `created_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'web developer', '1', 1, '2020-02-02 23:21:51', '2020-02-03 01:48:47', NULL),
(2, 'jr web developer', '1', 2, '2020-02-03 00:01:44', '2020-02-10 00:35:24', NULL),
(3, 'jr php developer', '1', 2, '2020-02-10 00:24:58', '2020-02-10 00:24:58', NULL),
(4, 'dasda', '1', 1, '2020-02-13 23:54:30', '2020-02-20 05:53:46', '2020-02-20 11:23:46'),
(5, 'sd', '1', 1, '2020-02-13 23:55:07', '2020-02-20 05:53:45', '2020-02-20 11:23:45'),
(6, 'fgsdfgsdfg', '1', 4, '2020-02-14 02:05:53', '2020-02-20 05:53:43', '2020-02-20 11:23:43'),
(7, 'fgsdfgsdfgsssssss', '1', 1, '2020-02-14 04:14:05', '2020-02-20 05:53:43', '2020-02-20 11:23:43'),
(8, 'dinesh', '1', 1, '2020-02-14 04:47:10', '2020-02-20 05:48:36', '2020-02-20 11:18:36'),
(9, 'sd', '1', 1, '2020-02-14 04:50:12', '2020-02-14 05:00:17', '2020-02-14 10:30:17'),
(10, 'sd', '1', 1, '2020-02-14 04:51:20', '2020-02-14 05:00:14', '2020-02-14 10:30:14'),
(11, 'sdeee', '1', 1, '2020-02-14 04:51:55', '2020-02-14 04:59:46', '2020-02-14 10:29:46'),
(12, 'sdbbbbaaa', '1', 1, '2020-02-14 04:52:11', '2020-02-14 04:59:43', '2020-02-14 10:29:43');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2016_06_01_000001_create_oauth_auth_codes_table', 2),
(5, '2016_06_01_000002_create_oauth_access_tokens_table', 2),
(6, '2016_06_01_000003_create_oauth_refresh_tokens_table', 2),
(7, '2016_06_01_000004_create_oauth_clients_table', 2),
(8, '2016_06_01_000005_create_oauth_personal_access_clients_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('0656c43a739cc520a443e5e78b579d38235821c1126741be618138ddf03d395f6a2c9f0189498a39', 2, 1, 'Personal Access Token', '[]', 0, '2020-02-15 01:12:21', '2020-02-15 01:12:21', '2021-02-15 06:42:21'),
('06b1b8b20df4e0b5abab621ee9105e6f7f5683f3cf74000dc72a2b4a4f253ddeabbf53a7474f6b2a', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-11 01:12:59', '2020-02-11 01:12:59', '2021-02-11 06:42:59'),
('0ad7d0d4ccc9b7e0f2552fe2a5f52da7651aff406240418b783aa2eae0636d917b42fef35e0ab8a1', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-04 23:15:10', '2020-02-04 23:15:10', '2021-02-05 04:45:10'),
('0adf462cae14a3fdd5d74ef9f82a4caa698e15b64185232883a4c17dd1bee4f9738f0791b37a9b7c', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 01:10:59', '2020-02-10 01:10:59', '2021-02-10 06:40:59'),
('11ea5eac6eeafdca11521a553f0f6c3786c38659af8d5c33d3c97d734125bcc6bc6f82ac3cd0a9bd', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 00:59:05', '2020-02-10 00:59:05', '2021-02-10 06:29:05'),
('137d3661dee86d04ea6ec658ba2f4fe39bd818136618ed381bdad83e5918170b32b220bb7ca48b15', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-07 07:21:29', '2020-02-07 07:21:29', '2021-02-07 12:51:29'),
('156aab281f43773e7a5879380f3813d720e0fb19e6c14578bdf7fd778a53de50c235ed7df2a8a037', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 06:06:06', '2020-02-10 06:06:06', '2021-02-10 11:36:06'),
('15bfe42e82f35ece77514f7a6c1cf4844dd68c14553b47f6253de3e9351a588ec97317edd9fe187b', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 06:04:48', '2020-02-10 06:04:48', '2021-02-10 11:34:48'),
('172b950b354872229eb8375a5b3099431c71c4eff75320960134f8070ff115200a0fc2690af3446c', 4, 1, 'Personal Access Token', '[]', 0, '2020-02-10 23:36:01', '2020-02-10 23:36:01', '2021-02-11 05:06:01'),
('19f75ce35e64dee35020d778ddb36c5ef5af538fbff030a790803d7f14bf7298a4824fee3ff60334', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-05 00:41:07', '2020-02-05 00:41:07', '2021-02-05 06:11:07'),
('1b3d9ba63904cba78af908991ad217d30e76f2989727f41262cbe549e888c50bce88b753c846162f', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 06:03:57', '2020-02-10 06:03:57', '2021-02-10 11:33:57'),
('1b7dabed4cd02bb310faa5debac47849d843d798fc3fd7adf2dabeeae368d03d572d1b1266314ea7', 4, 1, 'Personal Access Token', '[]', 0, '2020-02-11 00:31:27', '2020-02-11 00:31:27', '2021-02-11 06:01:27'),
('1d6c5b8fb5fd3f5e361c080eb8a1527740201b2207fa5e34d222399c58d0f396860115a49c5cc864', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-25 01:03:34', '2020-02-25 01:03:34', '2021-02-25 06:33:34'),
('1e7dc736927dee7a260c7bcb699814958f0b599c758c669bab33bc9ebe0e9dd45e18b95c2cc06243', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-03 00:14:56', '2020-02-03 00:14:56', '2021-02-03 05:44:56'),
('2298a6031736c5b126f83abf6207e5806666d785b918a66a7ccd1f23fc5d5003fa0687cb8bfd3d28', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-15 07:02:09', '2020-02-15 07:02:09', '2021-02-15 12:32:09'),
('2962756cfdd633bf068c9a1625b386e1b13f1ee4cc2e9aa2f9e066a25ae4a2ff165180b8b673e48e', 2, 1, 'Personal Access Token', '[]', 0, '2020-02-07 07:24:01', '2020-02-07 07:24:01', '2021-02-07 12:54:01'),
('2b66d40958dd987106ce03f8cc7788b0c2114f029dfd75256b173d5c87a0df836b95b237a05d46da', 2, 1, 'Personal Access Token', '[]', 0, '2020-02-10 05:51:13', '2020-02-10 05:51:13', '2021-02-10 11:21:13'),
('36582f2907f7d869b532fe1fdfbc1398f815fee860e2ebedc7f1a949b5688f2e7df387e6e63ba0d2', 2, 1, 'Personal Access Token', '[]', 0, '2020-02-09 23:07:36', '2020-02-09 23:07:36', '2021-02-10 04:37:36'),
('3c0761646e5d53512676e94705056d08aaafa1bd8d1298ea42cf569a440b37c9db59eec662c12889', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 01:14:39', '2020-02-10 01:14:39', '2021-02-10 06:44:39'),
('3e3005af0f2c62a01b2e385618b4fea5b6b45526b3c5a50b1f6b151e83b2bc11188894d0dca618fd', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-18 05:45:11', '2020-02-18 05:45:11', '2021-02-18 11:15:11'),
('3e99c32a403050077c6801237a99578e0602deaa5b886d66a8d4d7ca7d64ae634ea1bbcd8e0a5f85', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 00:59:29', '2020-02-10 00:59:29', '2021-02-10 06:29:29'),
('3fc61118e645013100fc9acb247ea0b336f9899ee67f4e32e3791196eca86c6aa8dee2e003f1af5c', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 01:19:20', '2020-02-10 01:19:20', '2021-02-10 06:49:20'),
('3fda5583e28e8f0798dd316b075c03aaf3fc91183acf457343029309b1d69071d4262ab7dd29c5ed', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-07 07:21:29', '2020-02-07 07:21:29', '2021-02-07 12:51:29'),
('41ee6f2f961a279cb9b124b4bd1151cda124f13c0ae2f2f153b7d5499b6ff6d59e0711b9127d7799', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 06:04:20', '2020-02-10 06:04:20', '2021-02-10 11:34:20'),
('427abc611fcbd1cde558f891e61e72909ccfe7456e51fc5e95f6829184cf9126adf9ae1201f20d8f', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-27 05:38:19', '2020-02-27 05:38:19', '2021-02-27 11:08:19'),
('4321bd91c34c9e6ccf6fd4d7b9442238373680fb0a191d6b2729548ff0b7273c07ab37a157f118d9', 4, 1, 'Personal Access Token', '[]', 0, '2020-02-12 23:19:00', '2020-02-12 23:19:00', '2021-02-13 04:49:00'),
('44e3256293af57caaab267ed07b837f2a9c56e0937234dbbb7639530db4d2b9a609ce205684cf973', 2, 1, 'Personal Access Token', '[]', 0, '2020-02-16 23:00:09', '2020-02-16 23:00:09', '2021-02-17 04:30:09'),
('45359a55c9779c1fbe61ea9fd14e7662a23a981d2224dd8301fdd363189b315fd3a737bffa107e95', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 01:21:11', '2020-02-10 01:21:11', '2021-02-10 06:51:11'),
('461b3b74da9303aca5215b7b5c5231b3e368402df700dec35a1f7aa44aa798193d42e783006fd713', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-11 01:38:26', '2020-02-11 01:38:26', '2021-02-11 07:08:26'),
('4c8d208fa6741ec94c3d2e7a4513cff04b69d57b80624f079a647c7d246a3190c342501a332756b5', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 02:20:05', '2020-02-10 02:20:05', '2021-02-10 07:50:05'),
('532cc80f7873337ceb745cc7b72e800f2646381b795d9cffbc580b37eebbc2b03340b75b33b0b7a7', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 01:18:53', '2020-02-10 01:18:53', '2021-02-10 06:48:53'),
('5b7fe0a39da8035fea3b04bfe68c6275cdaf23c6ef519ff8182b04353294a7a651f0ab94a23e3981', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 06:02:59', '2020-02-10 06:02:59', '2021-02-10 11:32:59'),
('5c9a7d826053a32c6b3eaf739ad3ef5c395b522e910de07a11ba84f308c8aa60260dfd30e24a3599', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-25 00:48:08', '2020-02-25 00:48:08', '2021-02-25 06:18:08'),
('5d6731561077b77f25b07710e7ccaa21e7f60a5849ec5eaf2f0729c66298d672177a479d460c910a', 2, 1, 'Personal Access Token', '[]', 0, '2020-02-07 07:22:52', '2020-02-07 07:22:52', '2021-02-07 12:52:52'),
('5f3e56ea00cc55d2928a5eb84fe40ed7db5955171a053f51bfc6634d6e6a9d2c1b3693b84a0775c0', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 01:11:39', '2020-02-10 01:11:39', '2021-02-10 06:41:39'),
('62a59ee94d9bc4036a57e4171365b5a2796ca2a2722ff94c6cc57d2d450be30e68e1f14eb2922350', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-27 02:51:27', '2020-02-27 02:51:27', '2021-02-27 08:21:27'),
('633598a534ef6ad302424276ce2110d1560737a75699b8d688434f1e07e201a93a5ad3bb35652177', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-07 07:21:29', '2020-02-07 07:21:29', '2021-02-07 12:51:29'),
('6397dade4ba65353d5e336e42eccf2ddff968121086ef430dab60584253b6d306d6a9bd7754338ec', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 00:50:12', '2020-02-10 00:50:12', '2021-02-10 06:20:12'),
('649a09820b076dec6dd1564b684ebd1bfd62e41d1bc0a292f9376ea91b3250011d5973d48c33bdff', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-25 00:49:27', '2020-02-25 00:49:27', '2021-02-25 06:19:27'),
('6b75d7c32f2f7ff3aeb5d09b3823add2daca23ae33fd2c66bac0d3c50c9d21795bd3b2a663fae9f2', 2, 1, 'Personal Access Token', '[]', 0, '2020-02-14 07:13:35', '2020-02-14 07:13:35', '2021-02-14 12:43:35'),
('6ba17664bf6a722eb8d4c383f602ca134c7ad200e2cd56b11535589155e706f263421d2bcacc0663', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 01:12:08', '2020-02-10 01:12:08', '2021-02-10 06:42:08'),
('6c4bfa2ea24fdcca467a8f9a8ffe1188dfe3b146d4704532174a23020b65bb32045e5584a001d581', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-05 02:14:18', '2020-02-05 02:14:18', '2021-02-05 07:44:18'),
('6c8d61af3bc9f3958f1fa274011bd007ae7eecb7fe485cbefd91bc4df9412d3969ecca11c6f88aa6', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 01:05:39', '2020-02-10 01:05:39', '2021-02-10 06:35:39'),
('71c00154e7ba7128626a47e98a73afd3b2ef7eb422a2945779d45e180653468bb50397ee856e2591', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-25 23:52:17', '2020-02-25 23:52:17', '2021-02-26 05:22:17'),
('71e51a9f8e9a99b869a3116692ae4de34eefafb2c6251efdf75753d2296a59a005f05d357ddc5618', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 00:58:20', '2020-02-10 00:58:20', '2021-02-10 06:28:20'),
('77529b7f78c48f5ad573e3ef74c7471dccf258a6a4af351a620e4250149c05bdcee5e691dedc2580', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-27 02:50:16', '2020-02-27 02:50:16', '2021-02-27 08:20:16'),
('78e87a08297add317621e2538267b6968bad2404db9dc41023dec26e852e3ea4ff83c82a4f18c474', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-27 02:29:23', '2020-02-27 02:29:23', '2021-02-27 07:59:23'),
('7969851048ac48e3f00d7662b14634c59425d8ca522c189a54f7fd313ae573ebe497648a3cf6a428', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-26 04:18:50', '2020-02-26 04:18:50', '2021-02-26 09:48:50'),
('7aa70993150beff338ee758a56e6977e9f05b6ca81508383e41516c86170304a86bbe9edd5f01e73', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-05 02:13:57', '2020-02-05 02:13:57', '2021-02-05 07:43:57'),
('7c6c6536e1ca157faa6c72aee7dd7f050bd40b6de4a2ba01c191c1d87e21188d32782d7b3febf8f1', 1, 1, 'Personal Access Token', '[]', 0, '2020-01-27 06:33:50', '2020-01-27 06:33:50', '2021-01-27 12:03:50'),
('7e2d63d6e166f8ad70adbf09014912cc633e3f1fca3fb14cbbd855d04b72f015516c14d4a3989209', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-13 01:38:02', '2020-02-13 01:38:02', '2021-02-13 07:08:02'),
('88d6d6b154263a3bf6674af3b502bb8780c324b805167a8091d133553602a84f9a57784d432c7753', 2, 1, 'Personal Access Token', '[]', 0, '2020-02-25 22:55:15', '2020-02-25 22:55:15', '2021-02-26 04:25:15'),
('89efcfda90ea11ea310b9e68977e326359b808e4eacc567fbb6696c3d317d43b038d66a06dee8b87', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-03 00:14:42', '2020-02-03 00:14:42', '2021-02-03 05:44:42'),
('8d0258663d8c3d1a6cd1100f56af3eed7d127d58e34f451143effb8034529e0dafa3314cb999d3ae', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 01:19:39', '2020-02-10 01:19:39', '2021-02-10 06:49:39'),
('9ccb57d129824b3151e97eb07e90d224a8afd8512a01fc6cbff50cecf6ea97cc50b6428a0850223e', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-07 07:21:30', '2020-02-07 07:21:30', '2021-02-07 12:51:30'),
('9d76479d9e016e4bfb6076f287390a0194ff6034a9ac0fbdc5042f19bdbea50efdd3b70fb2824102', 2, 1, 'Personal Access Token', '[]', 0, '2020-02-07 07:25:37', '2020-02-07 07:25:37', '2021-02-07 12:55:37'),
('a1e353c6588244eae25497459560e938350a11038e5093783b13394aa96c84982ac6d24ed6fb2f07', 4, 1, 'Personal Access Token', '[]', 0, '2020-02-11 00:49:31', '2020-02-11 00:49:31', '2021-02-11 06:19:31'),
('a4a1c75c7323072e02ed261273fcbf62612f25f3985d27ba4974c8698ab660142d323e1905e43477', 4, 1, 'Personal Access Token', '[]', 0, '2020-02-11 00:26:50', '2020-02-11 00:26:50', '2021-02-11 05:56:50'),
('a7a9fb24a415710a71e913eccb9ad9d06d80598c01b14b6102b528a77d165fe18d23d5544e269010', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 01:02:26', '2020-02-10 01:02:26', '2021-02-10 06:32:26'),
('aa1f24eb60b18c6210f66faca37f3056b6a39090ad11ca578547d65ab4ce2916a7ff6c849f69dcd1', 2, 1, 'Personal Access Token', '[]', 0, '2020-02-14 06:40:31', '2020-02-14 06:40:31', '2021-02-14 12:10:31'),
('aae60af83fc22f70ee9c48d1eccf7cc8c3b964e457b8819560692dfa05263e1f3b50b8332076d1d7', 2, 1, 'Personal Access Token', '[]', 0, '2020-02-10 05:52:18', '2020-02-10 05:52:18', '2021-02-10 11:22:18'),
('b1f368edf382ba415f563b446104209c9964793c0494aa330e69004f25ed840df0dd2a33a71aa601', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 01:05:12', '2020-02-10 01:05:12', '2021-02-10 06:35:12'),
('b59a9532165f41527454ccb81618de80ee68f637419251ab49b64b33984f1e797a33f9ad12e40885', 1, 1, 'Personal Access Token', '[]', 0, '2020-01-30 00:43:31', '2020-01-30 00:43:31', '2021-01-30 06:13:31'),
('bc343383610f1439b4ff7b5eaf77a65c8d7055657b02cd591b436f8532f20fd356e17299d0990a8c', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 01:12:08', '2020-02-10 01:12:08', '2021-02-10 06:42:08'),
('c0962a1bf56de332acbc99dc3295f9930ab49d84acf159c029354cf75926675f17a9e0b494f506d7', 2, 1, 'Personal Access Token', '[]', 0, '2020-02-12 01:49:43', '2020-02-12 01:49:43', '2021-02-12 07:19:43'),
('c250ac37588bf24030bbe308c8c93a4553fa348744fea9983dcf27d563ad1e9ec40512a1e88f0691', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 01:13:47', '2020-02-10 01:13:47', '2021-02-10 06:43:47'),
('c673b17a28c535da4ac39566d854acf17c3f887b708d043ad97b1d9fedf6c02426046c96d7c4a4b3', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-27 02:48:37', '2020-02-27 02:48:37', '2021-02-27 08:18:37'),
('c8bde32c4d9a3f568981889996e3cf6c3bfc8ef8e7c5067ebbca24b7caa1c798c0d5b42449c5aa84', 4, 1, 'Personal Access Token', '[]', 0, '2020-02-14 02:51:22', '2020-02-14 02:51:22', '2021-02-14 08:21:22'),
('c8e2183c711c6b8a10cdb88b39c16fbfa17462eb6c5e97d7d7fad096ec54d10ec905b57dfcff080c', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-14 02:44:33', '2020-02-14 02:44:33', '2021-02-14 08:14:33'),
('d57794f371e5b408695410c443f6d4b26b4016d37b421684b999615399e63f136375b75f5852f9b9', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-05 00:41:34', '2020-02-05 00:41:34', '2021-02-05 06:11:34'),
('d7524b299abf67cb10d35d787588040c0ee9df11538fe66beb0fb3f5e055508077bfd1dadde801b3', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-15 04:53:13', '2020-02-15 04:53:13', '2021-02-15 10:23:13'),
('da9f3ade009534481f811f13946819245be553847aac5fa44a184743978f468588521edfc4ac26f2', 4, 1, 'Personal Access Token', '[]', 0, '2020-02-10 23:31:43', '2020-02-10 23:31:43', '2021-02-11 05:01:43'),
('dc61822c813b26e7494a7b29b8ee2b0eb7a00f3c6d9e36f2dd017dc2df9fa02ceea49b1b51ed446f', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-18 05:48:36', '2020-02-18 05:48:36', '2021-02-18 11:18:36'),
('dd4920ba489293f43e55c97cc3d0b70c133073d06052e658be7624bbe8a80d45e3a95f845219cf4b', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-11 02:11:03', '2020-02-11 02:11:03', '2021-02-11 07:41:03'),
('e4a1f1b850ea4c6921f7da0ede829d03c3403cdf754d9cb1cf9d737224560c4da79ae0d405845cde', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-13 01:46:33', '2020-02-13 01:46:33', '2021-02-13 07:16:33'),
('e56efdd6ce5594afc3a170183cbf6f3ff9eaaebc12fc8e402d24314f1829ce0a3435cb2e56a9d898', 2, 1, 'Personal Access Token', '[]', 0, '2020-02-14 06:38:08', '2020-02-14 06:38:08', '2021-02-14 12:08:08'),
('eaf3fab347502044053b74f78d36e5edd5956bc9def6da446834c09c4e7fb7b2052d6b3d2061138c', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-05 04:14:25', '2020-02-05 04:14:25', '2021-02-05 09:44:25'),
('f058a6b6eed511c50e97b191a4bd13831f91e3f53e490632867d5b5bf91f7ee6d0aa2984523655b1', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 06:06:06', '2020-02-10 06:06:06', '2021-02-10 11:36:06'),
('f1eee8340b0ecbbaab78565318fb1749b3b92955bb8f4a73496b3279c999a61fc996f7e32c11da5f', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 01:06:07', '2020-02-10 01:06:07', '2021-02-10 06:36:07'),
('f2d2272933984ff22aaea3b634e86924a72757244dafcdef2d43713c857a5f52bb21a16adc755fca', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 01:08:47', '2020-02-10 01:08:47', '2021-02-10 06:38:47'),
('f31483a462f7ce6b414814b695616d785fe251fd10634eae914aa160115076009892c21014ba9587', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-05 00:32:10', '2020-02-05 00:32:10', '2021-02-05 06:02:10'),
('f3bf58695ad84b3b003e727aa51977e4ef7bf26ee27fe0626725e0fcaae56dd7aed4a6e39a84a4f9', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 01:24:30', '2020-02-10 01:24:30', '2021-02-10 06:54:30'),
('f6dc553b924b5b85f32aed90273f58305789215be52692bfa8d232ef3692f0a008e4f97f13262cca', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-25 00:59:01', '2020-02-25 00:59:01', '2021-02-25 06:29:01'),
('f83a8654e6f04f16654dd4d84201f1deb60b6fba269d803994f6cfd9fa9012749dd000e9c88a596b', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-10 01:02:54', '2020-02-10 01:02:54', '2021-02-10 06:32:54'),
('fabb4d25f20b72ca6c4304086ce7f5aa1dc2c1025e555208a6f1cde8e4ee78498c444e0ccd7fed55', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-15 07:01:58', '2020-02-15 07:01:58', '2021-02-15 12:31:58'),
('fc7f1bd5e02b8e49e87ef57840f9342c95b0d7e0bd90a98e1a4e31ad037200d2fbaa3fb5868ce15e', 1, 1, 'Personal Access Token', '[]', 0, '2020-02-27 02:47:10', '2020-02-27 02:47:10', '2021-02-27 08:17:10');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Laravel Personal Access Client', 'usyB2HI2CpKJMXK7bdgaVdC1u86cpbrEXP7QWBxL', 'http://localhost', 1, 0, 0, '2020-01-26 23:22:58', '2020-01-26 23:22:58'),
(2, NULL, 'Laravel Password Grant Client', '92BJq3dUnyxIFnVL7oMjRm2HCLCWITbaMGLnlWHU', 'http://localhost', 0, 1, 0, '2020-01-26 23:22:58', '2020-01-26 23:22:58');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2020-01-26 23:22:58', '2020-01-26 23:22:58');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `project_id` int(11) NOT NULL,
  `is_active` enum('1','0','','') NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permission`
--

CREATE TABLE `permission` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `is_active` enum('1','0','','') NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `permission`
--

INSERT INTO `permission` (`id`, `name`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Add Project', '1', '2020-01-29 12:39:08', '2020-01-29 12:39:08'),
(2, 'Create Task', '1', '2020-01-29 12:39:26', '2020-01-29 12:39:26'),
(3, 'Delete', '1', '2020-01-29 12:39:37', '2020-01-29 12:39:37'),
(4, 'View', '1', '2020-01-29 12:39:46', '2020-01-29 12:39:46');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(11) NOT NULL,
  `project_name` varchar(120) NOT NULL,
  `project_owner` varchar(120) DEFAULT NULL,
  `project_from` varchar(120) DEFAULT NULL,
  `project_type` varchar(120) DEFAULT NULL,
  `project_for` text DEFAULT NULL,
  `deadline` date DEFAULT NULL,
  `priority` varchar(120) DEFAULT NULL,
  `project_description` longtext DEFAULT NULL,
  `pages` text DEFAULT NULL,
  `document` varchar(250) DEFAULT NULL,
  `designing_est_time` varchar(120) DEFAULT '00:00',
  `ios_est_time` varchar(120) DEFAULT '00:00',
  `development_est_time` varchar(120) DEFAULT '00:00',
  `android_est_time` varchar(120) DEFAULT '00:00',
  `created_by` int(11) NOT NULL,
  `status` enum('pending','ongoing','onhold','completed','ontesting') NOT NULL DEFAULT 'pending',
  `is_active` enum('1','0','','') NOT NULL DEFAULT '1',
  `cancellation_reason` longtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `project_name`, `project_owner`, `project_from`, `project_type`, `project_for`, `deadline`, `priority`, `project_description`, `pages`, `document`, `designing_est_time`, `ios_est_time`, `development_est_time`, `android_est_time`, `created_by`, `status`, `is_active`, `cancellation_reason`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'timesheet', 'ratan singh', 'Sale', 'Static', '[{\"display\":\"marketing\",\"value\":\"marketing\"},{\"display\":\"blog post\",\"value\":\"blog post\"}]', '2020-02-29', 'Medium', 'In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document or a typeface without relying on meaningful content.', '[{\"display\":\"home\",\"value\":\"home\"},{\"display\":\"blog\",\"value\":\"blog\"},{\"display\":\"contact-us\",\"value\":\"contact-us\"}]', 'document/4V2VamEXnWovSHe91madIiiiug0Bt9ZtW6TRxd3L.png', '01:00', '01:00', '01:00', '01:00', 1, 'pending', '1', NULL, '2020-02-26 06:24:22', '2020-02-26 06:24:22', NULL),
(2, 'recruiter', 'ratar singh', 'Sale', 'Static', '[{\"display\":\"development\",\"value\":\"development\"},{\"display\":\"ios develpment\",\"value\":\"ios develpment\"}]', '2020-02-29', 'Low', 'lorem ipsum is dummy text', '[{\"display\":\"home about\",\"value\":\"home about\"},{\"display\":\"services\",\"value\":\"services\"},{\"display\":\"about\",\"value\":\"about\"}]', 'document/wxPm2lqPvnbO8LNYwxX8Yhq2MH8utJkn0T8IVvG6.png', '01:00', '01:00', '01:00', '02:00', 1, 'pending', '1', NULL, '2020-02-26 07:23:56', '2020-02-26 07:23:56', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `project_users`
--

CREATE TABLE `project_users` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `project_users`
--

INSERT INTO `project_users` (`id`, `project_id`, `user_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 2, 2, 1, '2020-02-11 18:30:00', '2020-02-11 18:30:00'),
(2, 2, 3, 0, '2020-02-20 02:46:00', '2020-02-20 02:46:10'),
(3, 1, 2, 1, '2020-02-20 02:46:24', '2020-02-20 02:46:24'),
(4, 1, 3, 1, '2020-02-20 02:46:44', '2020-02-20 02:46:44');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `name` varchar(51) NOT NULL,
  `is_active` enum('1','0') NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Admin', '1', '2020-01-24 11:33:11', '2020-01-24 11:33:11', NULL),
(2, 'Project Manger', '1', '2020-01-24 11:33:28', '2020-01-24 11:33:28', NULL),
(3, 'Employee', '1', '2020-01-24 11:33:38', '2020-01-24 11:33:38', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `task_name` varchar(120) NOT NULL,
  `department` int(11) NOT NULL,
  `priority` varchar(120) NOT NULL,
  `assign_to` int(11) NOT NULL,
  `description` longtext DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `duration` varchar(120) NOT NULL,
  `status` enum('pending','ongoing','onhold','completed','ontesting') NOT NULL DEFAULT 'pending',
  `developer_comment` longtext DEFAULT NULL,
  `developer_start_date` date DEFAULT NULL,
  `developer_time_est` varchar(120) DEFAULT NULL,
  `is_active` enum('1','0','','') NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `project_id`, `task_name`, `department`, `priority`, `assign_to`, `description`, `start_date`, `end_date`, `start_time`, `end_time`, `duration`, `status`, `developer_comment`, `developer_start_date`, `developer_time_est`, `is_active`, `created_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'blog page', 1, 'low', 2, 'asdfdf sdfsdf sdf sdfk sdf sdfsdfadfk', '2018-01-01', NULL, NULL, NULL, '11:01', 'completed', NULL, NULL, NULL, '1', 1, '2020-02-20 06:29:50', '2020-02-25 23:26:18', NULL),
(2, 2, 'contact page', 1, 'low', 2, 'ghjg', NULL, NULL, NULL, NULL, '01:00', 'pending', NULL, NULL, NULL, '1', 1, '2020-02-20 06:36:40', '2020-02-24 06:24:26', NULL),
(3, 2, 'create page', 2, 'low', 2, 'lorem ipsum is dummy text', NULL, NULL, NULL, NULL, '01:00', 'completed', NULL, NULL, NULL, '1', 1, '2020-02-24 06:13:44', '2020-02-26 01:23:17', NULL),
(4, 2, 'create page', 2, 'low', 2, 'aaaaaaaaaaaaaaa', NULL, NULL, NULL, NULL, '01:00', 'pending', NULL, NULL, NULL, '1', 1, '2020-02-25 00:17:56', '2020-02-26 01:35:35', NULL),
(5, 1, 'create dashboard', 2, 'low', 2, 'asdfdf sdfsdf sdf sdfk sdf sdfsdfadfk', NULL, NULL, NULL, NULL, '11:01', 'pending', NULL, NULL, NULL, '1', 1, '2020-02-26 01:32:59', '2020-02-26 01:32:59', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `fname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lname` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `designation_id` int(11) DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_no` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` int(11) DEFAULT 3 COMMENT '1=admin, 2= pm, 3 =employee',
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lname`, `department`, `designation_id`, `email`, `phone_no`, `role`, `email_verified_at`, `password`, `created_by`, `remember_token`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'ratan', 'chand', 'Admin', NULL, 'admin@gmail.com', NULL, 1, NULL, '$2y$10$zW52vRO7ercm55/feW4xIudnyxZtHU1ttNrkZUNHxvz0IlVmjHfLG', NULL, NULL, 0, '2020-01-27 06:57:35', '2020-01-27 06:57:35', NULL),
(2, 'dinesh', 'dhiman', '2', 1, 'dinesh@gmail.com', '1111111111111', 2, NULL, '$2y$10$HdFp8vWfSFCL6.lTMAt/7.Q06sq6KNYRnS4Hy4ygi8h8chd9Sv/8e', NULL, NULL, 1, '2020-01-27 06:57:52', '2020-02-18 05:54:56', NULL),
(3, 'dinesh', 'sharma', '2', 3, 'dinesh2@gmail.com', '1111111111111', 2, NULL, '$2y$10$1fvgo5yI5NU5tfY1/0EuWOzzH1Qfouzc1GBTqesP4h/uvofdLHtBK', NULL, NULL, 1, '2020-02-03 00:24:34', '2020-02-20 05:59:04', NULL),
(4, 'b', 'arya', '1', 2, 'b@gmail.com', '1111111111111', 3, NULL, '$2y$10$jSAr/RwmjhwioDlJErOk9OQEO7huLz9O6Iuf/udyGbHPiTNuB3Iuy', NULL, NULL, 1, '2020-02-03 00:24:34', '2020-02-27 05:42:32', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_permissions`
--

CREATE TABLE `user_permissions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `addproject` tinyint(1) DEFAULT 0,
  `view` tinyint(1) NOT NULL DEFAULT 0,
  `createtask` tinyint(1) NOT NULL DEFAULT 0,
  `delete` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  `is_active` enum('1','0') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_permissions`
--

INSERT INTO `user_permissions` (`id`, `user_id`, `type`, `addproject`, `view`, `createtask`, `delete`, `created_at`, `updated_at`, `deleted_at`, `is_active`) VALUES
(1, 1, 1, 1, 0, 0, 0, '2020-02-17 06:04:24', '2020-02-17 06:04:24', NULL, '0'),
(2, 1, 2, 1, 0, 0, 0, '2020-02-17 06:04:24', '2020-02-17 06:04:24', NULL, '1'),
(3, 4, 0, 1, 0, 1, 1, '2020-02-17 05:53:06', '2020-02-18 05:53:58', NULL, '1'),
(4, 3, 0, 1, 1, 0, 1, '2020-02-18 00:16:10', '2020-02-26 23:13:58', NULL, '1'),
(5, 2, 0, 1, 1, 0, 1, '2020-02-18 00:37:13', '2020-02-27 05:42:19', NULL, '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `designation`
--
ALTER TABLE `designation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_personal_access_clients_client_id_index` (`client_id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `permission`
--
ALTER TABLE `permission`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project_users`
--
ALTER TABLE `project_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_permissions`
--
ALTER TABLE `user_permissions`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `designation`
--
ALTER TABLE `designation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permission`
--
ALTER TABLE `permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `project_users`
--
ALTER TABLE `project_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `user_permissions`
--
ALTER TABLE `user_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
